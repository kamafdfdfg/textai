<?php

namespace AIKit\Dependencies\GuzzleHttp\Exception;

use AIKit\Dependencies\Psr\Http\Client\ClientExceptionInterface;

interface GuzzleException extends ClientExceptionInterface
{
}
