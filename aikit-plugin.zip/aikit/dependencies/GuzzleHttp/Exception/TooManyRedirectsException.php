<?php

namespace AIKit\Dependencies\GuzzleHttp\Exception;

class TooManyRedirectsException extends RequestException
{
}
