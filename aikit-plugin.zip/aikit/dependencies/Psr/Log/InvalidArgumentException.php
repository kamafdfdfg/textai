<?php

namespace AIKit\Dependencies\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
