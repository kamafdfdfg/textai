<?php
/**
 * FieldSchema
 *
 * @since     Mar 2023
 * @author    Haydar KULEKCI <haydarkulekci@gmail.com>
 */

namespace AIKit\Dependencies\Qdrant\Models\Field;

interface FieldSchema
{
    public function schema();
}