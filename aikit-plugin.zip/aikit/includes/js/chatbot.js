"use strict";
jQuery(function($) {

    aikitChatbot.previousMessages = [];
    let isLivePreview = false;

    // deactivate all inputs inside .aikit-deactivated-form class
    $(".aikit-deactivated-form *").prop('disabled', true);

    $(".aikit-chatbot-send").click(function (event) {
        event.preventDefault();

        sendChatbotMessage();
    });

    // on enter key press, send the message
    $(".aikit-chatbot-message").keypress(function (event) {
        // if shift key is pressed, do nothing
        if (event.shiftKey) {
            return;
        }

        if (event.keyCode === 13) {
            event.preventDefault();
            sendChatbotMessage();
        }
    });

    $(".aikit-chatbot-header").click(function (event) {

        $(".aikit-chatbot").animate({ bottom: '-600px' }, 250, "swing", function() {
            $(".aikit-chatbot").toggleClass('aikit-chatbot-collapsed');
            $(".aikit-chatbot").animate({ bottom: '0px' }, 70, "swing");
        });
    })


    const sendChatbotMessage = () => {
        let message = $(".aikit-chatbot-message").val();

        if (message === '') {
            return;
        }

        if ($(".aikit-chatbot-send").prop('disabled')) {
            return;
        }

        // deactivate the send button
        $(".aikit-chatbot-send").prop('disabled', true);
        $(".aikit-chatbot-send").css('opacity', '0.5');

        addMessageToChat(message, "reply");

        let loading = $('<span class="aikit-chat-bubble-loading-container"><span class="aikit-chat-bubble aikit-chat-bubble-loading"><span class="aikit-typing"><span class="aikit-dot"></span><span class="aikit-dot"></span><span class="aikit-dot"></span></span></span></span>');
        $(".aikit-chatbot-messages").append(loading);
        loading.hide().fadeIn(300);

        $(".aikit-chatbot-messages").animate({ scrollTop: $(".aikit-chatbot-messages").prop("scrollHeight")}, 50);

        if (isLivePreview) {
            // add a test message
            loading.remove();
            addMessageToChat("This is a test message from the live preview.");
            // reactivate the send button
            $(".aikit-chatbot-send").prop('disabled', false);

            $(".aikit-chatbot-send").css('opacity', '1');

            $(".aikit-chatbot-message").val('');

            return;
        }

        $.ajax({
            type: "POST",
            url: aikitChatbot.siteUrl + '/?rest_route=/aikit/chatbot/v1/chat',
            data: JSON.stringify({
                message: message,
                // json previous messages
                previous_messages: JSON.stringify(aikitChatbot.previousMessages),
                page_content: aikitChatbot.pageContent,
            }),
            dataType: "json",
            encode: true,
            headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': aikitChatbot.nonce,
            },
        }).done(function (data) {
            aikitChatbot.previousMessages.push({
                message: message,
                author: 'user',
            });

            aikitChatbot.previousMessages.push({
                message: data.message,
                author: 'assistant',
            });

            data.message = data.message.replace(/\n/g, '<br>');

            data.message = data.message.replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank">$1</a>');

            loading.remove();
            addMessageToChat(data.message)

            // reactivate the send button
            $(".aikit-chatbot-send").prop('disabled', false);
            $(".aikit-chatbot-send").css('opacity', '1');

        }).fail(function (data) {
            if (data.responseJSON) {
                data = data.responseJSON;
            }

            if (data.show_in_alert === true) {
                alert(data.message);
            } else {
                console.log(data);
            }

            addMessageToChat(data.chat_error, "error");

            // reactivate the send button
            $(".aikit-chatbot-send").prop('disabled', false);
            $(".aikit-chatbot-send").css('opacity', '1');
            loading.remove();
        });

        // clear the input
        $(".aikit-chatbot-message").val('');
    }

    const addMessageToChat = (message, type = "") => {
        let bubble = $('<span class="aikit-chat-bubble ' + type + '">' + message + '</span>');
        $(".aikit-chatbot-messages").append(bubble);
        bubble.hide().fadeIn(50);
        bubble.animate({ fontSize: '25px' }, 100).animate({ fontSize: '14px' }, 20);
        $(".aikit-chatbot-messages").animate({ scrollTop: $(".aikit-chatbot-messages").prop("scrollHeight")}, 50);
    }

    const generateBotStyles = () => {
        let headerBgColor = hashColorToRgb(aikitChatbot.mainColor, 1);
        let loadingColor = hashColorToRgb(aikitChatbot.mainColor, .7);
        let dot1 = hashColorToRgb(aikitChatbot.mainColor, .7);
        let dot2 = hashColorToRgb(aikitChatbot.mainColor, .4);
        let dot3 = hashColorToRgb(aikitChatbot.mainColor, .2);

        // remove the style if it exists
        $("#aikit-chatbot-style").remove();

        // output bot style to the head
        let style = '<style id="aikit-chatbot-style">';
        style += '.aikit-chatbot-header {';
        style += '    background-color: ' + headerBgColor + ';';
        style += '}';

        style += '.aikit-chat-bubble, .aikit-chat-bubble a {';
        style += '    background-color: ' + aikitChatbot.aiMessageBubbleColor + ';';
        style += '    color: ' + aikitChatbot.aiMessageTextColor + ';';
        style += '}';

        style += '.aikit-chat-bubble a {';
        style += '    text-decoration: underline;';
        style += '}';

        style += '.aikit-chat-bubble.reply {';
        style += '    background-color: ' + aikitChatbot.userMessageBubbleColor + ';';
        style += '    color: ' + aikitChatbot.userMessageTextColor + ';';
        style += '}';

        style += '@media only screen and (min-width: 768px) {';
        style += '.aikit-chatbot {';
        style += '    width: ' + aikitChatbot.width + 'px;';
        style += '    min-height: 500px;';
        style += '    right: 20px;';
        style += '}';
        style += '.aikit-chatbot-messages {';
        style += '    max-height: 368px;';
        style += '}';
        style += '}';

        style += '.aikit-chatbot-send {';
        style += '    background-color: ' + aikitChatbot.mainColor + ';';
        style += '}';

        style += '.aikit-chat-bubble.aikit-chat-bubble-loading {';
        style += '    background-color: ' + loadingColor + ';';
        style += '}';

        style += '.aikit-typing .aikit-dot {';
        style += '    background-color: ' + loadingColor + ';';
        style += '}';

        style += '.aikit-chatbot-header h2 {';
        style += '    color: ' + aikitChatbot.titleColor + ';';
        style += '}';

        style += '.aikit-chatbot-close {';
        style += '    color: ' + aikitChatbot.titleColor + ';';
        style += '}';

        style += ' @keyframes mercuryTypingAnimation {';
        style += '    0% {';
        style += '        transform: translateY(0px);';
        style += '        background-color: ' + dot1 + ';';
        style += '    }';
        style += '    28% {';
        style += '        transform: translateY(-7px);';
        style += '        background-color: ' + dot2 + ';';
        style += '    }';
        style += '    44% {';
        style += '        transform: translateY(0px);';
        style += '        background-color: ' + dot3 + ';';
        style += '    }';
        style += '}';

        style += '</style>';

        $('head').append(style);

        // show the chatbot
        $(".aikit-chatbot").show();

    }

    const activateLivePreview = () => {
        isLivePreview = true;
        // activate live editing
        $("input").on('input', function() {
            let setting = $(this).attr('data-setting');
            if (aikitChatbot[setting] !== undefined) {
                aikitChatbot[setting] = $(this).val();
            }

            updateLivePreview();
        });

        updateLivePreview();
    }

    const hashColorToRgb = (color, opacity) => {
        // turn # color to rgb and add opacity
        let colorRgb = color.replace('#', '');
        colorRgb = colorRgb.match(/.{1,2}/g);
        colorRgb = 'rgba(' + parseInt(colorRgb[0], 16) + ',' + parseInt(colorRgb[1], 16) + ',' + parseInt(colorRgb[2], 16) + ', ' + opacity + ')';

        return colorRgb;
    }

    const updateLivePreview = () => {

        generateBotStyles();

        // update get value from #aikit-chatbot-appearance-title and set it to the title
        let title = $("#aikit-chatbot-appearance-title").val();
        $(".aikit-chatbot-header h2").html(title);

        // same for first message
        let firstMessage = $("#aikit-chatbot-appearance-start-message").val();
        $(".aikit-chat-bubble:first").html(firstMessage);

        let inputTextPlaceholder = $("#aikit-chatbot-appearance-input-placeholder").val();
        $(".aikit-chatbot-message").attr('placeholder', inputTextPlaceholder);
    }

    // on load, generate the bot styles
    generateBotStyles();

    if (window.location.href.indexOf('page=aikit_chatbot') > -1) {
        activateLivePreview();
    }
});
