<?php

class AIKIT_Chatbot_Settings extends AIKIT_Page {
    // singleton
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance == null) {
            self::$instance = new AIKIT_Chatbot_Settings();
        }

        return self::$instance;
    }

    private $chatbot = null;
    private $embeddings = null;

    public function __construct()
    {
        add_action( 'rest_api_init', function () {
            register_rest_route( 'aikit/chatbot/v1', '/settings', array(
                'methods' => 'POST',
                'callback' => array($this, 'handle_request'),
                'permission_callback' => function () {
                    return is_user_logged_in() && current_user_can( 'manage_options' );
                }
            ));

        });
        $this->chatbot = AIKIT_Chatbot::get_instance();
        $this->embeddings = AIKIT_Embeddings::get_instance();
    }

    public function handle_request($data)
    {
        update_option('aikit_setting_chatbot_model', $data['chatbot_model']);
        update_option('aikit_setting_chatbot_prompt_stop_sequence', $data['chatbot_prompt_stop_sequence']);
        update_option('aikit_setting_chatbot_completion_stop_sequence', $data['chatbot_completion_stop_sequence']);
        update_option('aikit_setting_chatbot_show_on', $data['chatbot_show_on']);
        update_option('aikit_setting_chatbot_enabled', boolval($data['chatbot_enabled']));
        update_option('aikit_setting_chatbot_default_view', $data['chatbot_default_view']);
        update_option('aikit_setting_chatbot_context', $data['chatbot_context']);
        update_option('aikit_setting_chatbot_is_page_content_aware', boolval($data['chatbot_is_page_content_aware']));
        update_option('aikit_setting_chatbot_max_response_tokens', intval($data['chatbot_max_response_tokens']));
        update_option('aikit_setting_chatbot_show_only_for_roles', $data['chatbot_show_only_for_roles']);
        update_option('aikit_setting_chatbot_appearance_title', $data['chatbot_appearance_title']);
        update_option('aikit_setting_chatbot_appearance_input_placeholder', $data['chatbot_appearance_input_placeholder']);
        update_option('aikit_setting_chatbot_appearance_start_message', $data['chatbot_appearance_start_message']);
        update_option('aikit_setting_chatbot_appearance_width', $data['chatbot_appearance_width']);
        update_option('aikit_setting_chatbot_appearance_main_color', $data['chatbot_appearance_main_color']);
        update_option('aikit_setting_chatbot_appearance_title_color', $data['chatbot_appearance_title_color']);
        update_option('aikit_setting_chatbot_appearance_ai_message_bubble_color', $data['chatbot_appearance_ai_message_bubble_color']);
        update_option('aikit_setting_chatbot_appearance_ai_message_text_color', $data['chatbot_appearance_ai_message_text_color']);
        update_option('aikit_setting_chatbot_appearance_user_message_bubble_color', $data['chatbot_appearance_user_message_bubble_color']);
        update_option('aikit_setting_chatbot_appearance_user_message_text_color', $data['chatbot_appearance_user_message_text_color']);
        update_option('aikit_setting_chatbot_use_embeddings', $data['chatbot_use_embeddings']);
        update_option('aikit_setting_chatbot_embeddings_answer_formulation_prompt', $data['chatbot_embeddings_answer_formulation_prompt']);
        update_option('aikit_setting_chatbot_selected_embedding', $data['chatbot_selected_embedding']);

        return new WP_REST_Response( array(
            'success' => true,
            'message' => 'Settings saved'
        ), 200 );
    }

    public function render()
    {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html__( 'Chatbot', 'aikit' ); ?></h1>
            <p>
                <?php echo esc_html__( 'AIKit Chatbot allows you to create a chatbot that can be used on your website. You, or your users can use it to answer questions and provide support about your products or services.', 'aikit' ); ?>
            </p>

            <?php $this->show_settings()  ?>
        </div>
        <?php
    }

    private function show_settings()
    {
        $key = get_option('aikit_setting_openai_key');
        $deactivated_form_class = empty($key) ? 'aikit-deactivated-form' : '';

        if (empty($key)) {
            ?>
            <div class="notice notice-error">
                <p>
                    <?php echo esc_html__( 'Please set your OpenAI API key in the AIKit settings page in order to use Chatbot.', 'aikit' ); ?>
                </p>
            </div>
            <?php
        }

        $models = aikit_rest_openai_get_available_models($key);
        $models = $models === false ? [] : $models;

        if (empty($models)) {
            ?>
            <div class="notice notice-error">
                <p>
                    <?php echo esc_html__( 'Please make sure you are using a valid OpenAI API key to be able to load all available models.', 'aikit' ); ?>
                </p>
            </div>
            <?php

            $models = aikit_get_default_model_list();
        }

        $models = array_combine($models, $models);

        $available_wp_roles = get_editable_roles();
        $roles_array = [
                'all' => 'All',
        ];
        foreach ($available_wp_roles as $role => $role_data) {
            $roles_array[$role] = $role_data['name'];
        }

        $selected_model = get_option('aikit_setting_chatbot_model');

        $prompt_stop_sequence = get_option('aikit_setting_chatbot_prompt_stop_sequence');
        $completion_stop_sequence = get_option('aikit_setting_chatbot_completion_stop_sequence');

        $show_chatbot_on = get_option('aikit_setting_chatbot_show_on');
        $show_on_options = [
            'frontend' => __('Frontend Only', 'aikit'),
            'admin' => __('Admin Panel Only', 'aikit'),
            'all' => __('Admin Panel & Frontend', 'aikit'),
        ];

        $chatbot_enabled = get_option('aikit_setting_chatbot_enabled');
        $chatbot_default_view = get_option('aikit_setting_chatbot_default_view');
        $chatbot_context = get_option('aikit_setting_chatbot_context');
        $chatbot_is_page_content_aware = get_option('aikit_setting_chatbot_is_page_content_aware');
        $max_response_tokens = get_option('aikit_setting_chatbot_max_response_tokens');
        $show_only_for_roles = get_option('aikit_setting_chatbot_show_only_for_roles');

        $chatbot_appearance_title = get_option('aikit_setting_chatbot_appearance_title');
        $chatbot_appearance_input_placeholder = get_option('aikit_setting_chatbot_appearance_input_placeholder');
        $chatbot_appearance_start_message = get_option('aikit_setting_chatbot_appearance_start_message');
        $chatbot_appearance_width = get_option('aikit_setting_chatbot_appearance_width');
        $chatbot_appearance_main_color = get_option('aikit_setting_chatbot_appearance_main_color');
        $chatbot_appearance_title_color = get_option('aikit_setting_chatbot_appearance_title_color');
        $chatbot_appearance_ai_message_bubble_color = get_option('aikit_setting_chatbot_appearance_ai_message_bubble_color');
        $chatbot_appearance_ai_message_text_color = get_option('aikit_setting_chatbot_appearance_ai_message_text_color');
        $chatbot_appearance_user_message_bubble_color = get_option('aikit_setting_chatbot_appearance_user_message_bubble_color');
        $chatbot_appearance_user_message_text_color = get_option('aikit_setting_chatbot_appearance_user_message_text_color');

        $chatbot_use_embeddings = get_option('aikit_setting_chatbot_use_embeddings');
        $chatbot_embeddings_answer_formulation_prompt = get_option('aikit_setting_chatbot_embeddings_answer_formulation_prompt');
        $chatbot_chatbot_selected_embedding = get_option('aikit_setting_chatbot_selected_embedding');

        if (empty($chatbot_embeddings_answer_formulation_prompt)) {
            $chatbot_embeddings_answer_formulation_prompt = AIKIT_DEFAULT_SETTING_CHATBOT_EMBEDDINGS_ANSWER_FORMULATION_PROMPT;
        }

        $completed_embeddings = $this->embeddings->get_embeddings();

        $completed_embeddings_list = [
            '' => __('Select Embedding', 'aikit'),
        ];
        foreach ($completed_embeddings as $completed_embedding) {
            $completed_embeddings_list[$completed_embedding->id] = $completed_embedding->name;
        }

        if (empty($max_response_tokens)) {
            $max_response_tokens = 150;
        }

        if (empty($selected_model)) {
            $selected_model = 'gpt-3.5-turbo';
        }

        ?>
        <form id="aikit-chatbot-form" class="<?php echo $deactivated_form_class ?>" action="<?php echo get_site_url(); ?>/?rest_route=/aikit/chatbot/v1/settings" method="post">
            <h4><?php echo esc_html__( 'General settings', 'aikit' ); ?></h4>
            <div class="row mb-2 mt-4">
                <div class="col">
                    <?php
                        $this->_radio_button_set(
                            'aikit-chatbot-enabled',
                            __('Enable Chatbot', 'aikit'),
                            [
                                '1' => __('Yes', 'aikit'),
                                '0' => __('No', 'aikit'),
                            ],
                           $chatbot_enabled ? '1' : '0'
                        );
                    ?>
                </div>
            </div>
            <div class="row mb-4">
                <div class="col">
                    <?php
                    $this->_radio_button_set(
                        'aikit-chatbot-default-view',
                        __('Default view', 'aikit'),
                        [
                            'collapsed' => __('Collapsed', 'aikit'),
                            'expanded' => __('Expanded', 'aikit'),
                        ],
                        $chatbot_default_view === 'expanded' ? 'expanded' : 'collapsed'
                    );
                    ?>
                </div>
            </div>
            <div class="row mb-4">
                <div class="col">
                    <?php
                        $this->_drop_down(
                            'aikit-chatbot-model',
                            __('Chatbot model', 'aikit'),
                            $models,
                            $selected_model,
                            __('For best results, please use chat models like gpt-3.5-turbo or gpt-4.', 'aikit'),
                        );
                    ?>
                </div>
                <div class="col">
                    <?php
                        $this->_drop_down(
                            'aikit-chatbot-show-on',
                            __('Show Chatbot on', 'aikit'),
                            $show_on_options,
                            $show_chatbot_on,
                        );
                    ?>
                </div>

                <div class="col">
                    <?php
                    $this->_text_box(
                        'aikit-chatbot-max-response-tokens',
                        __('Max response tokens', 'aikit'),
                        null,
                        'number',
                        $max_response_tokens,
                        1,
                        1000,
                        1
                    );
                    ?>
                </div>

            </div>
            <div class="row mb-4">
                <div class="col">
                    <?php
                    $this->_text_box(
                        'aikit-chatbot-prompt-stop-sequence',
                        __('Prompt stop sequence (Optional)', 'aikit'),
                        null,
                        'text',
                        $prompt_stop_sequence,
                        null,
                        null,
                        null,
                        __('Please set this only if you are using a fine-tuned model. Leave empty if you are using any of the built-in models. Prompt stop sequence is used to mark the stop of the prompt.', 'aikit'),
                    );
                    ?>
                </div>
                <div class="col">
                    <?php
                    $this->_text_box(
                        'aikit-chatbot-completion-stop-sequence',
                        __('Completion stop sequence (Optional)', 'aikit'),
                        null,
                        'text',
                        $completion_stop_sequence,
                        null,
                        null,
                        null,
                        __('Please set this only if you are using a fine-tuned model. Leave empty if you are using any of the built-in models. Completion stop sequence is used to mark the stop of the completion.', 'aikit'),
                    );
                    ?>
                </div>
            </div>
            <div class="row mb-4">
                <div class="col">
                    <?php
                    $this->_radio_button_set(
                        'aikit-chatbot-use-embeddings',
                        __('Use embeddings', 'aikit'),
                        [
                            '1' => __('Yes', 'aikit'),
                            '0' => __('No', 'aikit'),
                        ],
                        $chatbot_use_embeddings ? '1' : '0',
                        'Embeddings allow you to store your own data in a way so that it can be used to answer Chatbot messages using similarity/semantic search (searching for meaning instead of exact words). Embeddings are currently the best and cheapest way to allow your Chatbot to answer your user questions about your products or services based on your own data.',
                        'https://youtu.be/VKtTOJ4MmJY',
                        __('Watch tutorial video', 'aikit')
                    );
                    ?>

                    <div class="aikit-embedding-options">
                        <div class="row mb-2">
                            <div class="col">
                                <?php
                                $this->_drop_down(
                                    'aikit-chatbot-selected-embedding',
                                    __('Embedding', 'aikit'),
                                    $completed_embeddings_list,
                                    $chatbot_chatbot_selected_embedding,
                                    __('Select the embedding you want to use to answer user questions. If you don\'t find your embedding in the list, please make sure the embedding creation process is already complete.', 'aikit'),
                                );
                                ?>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col">
                                <?php
                                $this->_text_area(
                                    'aikit-chatbot-embeddings-answer-formulation-prompt',
                                    __('Embedding Answer Formulation Prompt', 'aikit'),
                                    $chatbot_embeddings_answer_formulation_prompt,
                                    esc_html__('Embedding Answer formulation prompt will be used to formulate the answer to the user question along with the result of the embedding semantic search. What happens is the following. A user asks a question in the Chatbot, then using embeddings, a semantic search (search by meaning) occurs to retrieve the closest answer to the user question. Then, the answer formulation prompt is used to formulate the answer to the user question. For example, if the user asks "How much does your service cost?", the semantic search will retrieve the closest answer to this question, for example "Our prices start at $10 per month and you get a discount if you pay annually.". Then, the answer formulation prompt will be used to formulate the answer to the user question, for example "Service cost starts at $10 per month".', 'aikit') .
                                    '<br>' . esc_html__('Make sure to include the following placeholders in your prompt: ', 'aikit') . '<code>[[result]]</code>' . esc_html__(' and ', 'aikit') . '<code>[[question]]</code>' . esc_html__('. These placeholders will be replaced with the result (from vector database) and the question (asked by user) respectively.', 'aikit'),
                                    false
                                );
                                ?>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="row mb-4">
                <div class="col">
                    <?php
                        $this->_text_area(
                                'aikit-chatbot-context',
                            __('Chatbot Context', 'aikit'),
                            $chatbot_context,
                            __('You can use this field to set the behaviour of the chatbot. For example, use something like "You are a helpful assistant." or "Answer in the style of Shakespeare." .', 'aikit'),
                        );
                    ?>
                </div>
            </div>

            <div class="row mb-4">
                <div class="col">
                    <?php
                    $this->_drop_down(
                        'aikit-chatbot-show-only-for-roles',
                        __('Show Chatbot only for user role', 'aikit'),
                        $roles_array,
                        $show_only_for_roles,
                    );
                    ?>
                </div>
            </div>

            <div class="row mb-4 aikit-page-content-aware-container">
                <div class="col">
                    <?php
                    $this->_check_box(
                        'aikit-chatbot-is-page-content-aware',
                        __('Page content aware?', 'aikit'),
                        $chatbot_is_page_content_aware,
                        __('If enabled, the chatbot will be able to use the content of the current page to generate better responses. Important: it will increase your API costs!', 'aikit'),
                    );
                    ?>
                </div>
            </div>

            <input type="hidden" id="aikit-message-select-embedding" value="<?php echo esc_attr( __('Please select an embedding from embedding list.', 'aikit') ); ?>">

            <hr class="mb-4"/>

            <h4><?php echo esc_html__( 'Appearance', 'aikit' ); ?></h4>

            <div class="row mb-2">
                <div class="col">
                    <div class="row mb-2">
                        <div class="col">
                            <?php
                            $this->_text_box(
                                'aikit-chatbot-appearance-title',
                                __('Title', 'aikit'),
                                'title',
                                'text',
                                $chatbot_appearance_title
                            );
                            ?>
                        </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col">
                            <?php
                            $this->_text_box(
                                'aikit-chatbot-appearance-input-placeholder',
                                __('Input text placeholder', 'aikit'),
                                'inputPlaceholder',
                                'text',
                                $chatbot_appearance_input_placeholder
                            );
                            ?>
                        </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col">
                            <?php
                            $this->_text_box(
                                'aikit-chatbot-appearance-start-message',
                                __('Start Message', 'aikit'),
                                'startMessage',
                                'text',
                                $chatbot_appearance_start_message

                            );
                            ?>
                        </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col">
                            <?php
                            $this->_slider(
                                'aikit-chatbot-appearance-width',
                                __('Width (px)', 'aikit'),
                                'width',
                                $chatbot_appearance_width,
                                400,
                                700,
                                1
                            );
                            ?>
                        </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col">
                            <?php
                            $this->_color_picker(
                                'aikit-chatbot-appearance-main-color',
                                __('Main Color', 'aikit'),
                                'mainColor',
                                $chatbot_appearance_main_color

                            );
                            ?>
                        </div>
                        <div class="col">
                            <?php
                            $this->_color_picker(
                                'aikit-chatbot-appearance-title-color',
                                __('Title Color', 'aikit'),
                                'titleColor',
                                $chatbot_appearance_title_color
                            );
                            ?>
                        </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col">
                            <?php
                            $this->_color_picker(
                                'aikit-chatbot-appearance-ai-message-bubble-color',
                                __('AI Message Bubble Color', 'aikit'),
                                'aiMessageBubbleColor',
                                $chatbot_appearance_ai_message_bubble_color

                            );
                            ?>
                        </div>
                        <div class="col">
                            <?php
                            $this->_color_picker(
                                'aikit-chatbot-appearance-ai-message-text-color',
                                __('AI Message Text Color', 'aikit'),
                                'aiMessageTextColor',
                                $chatbot_appearance_ai_message_text_color
                            );
                            ?>
                        </div>
                    </div>
                    <div class="row mb-2">
                        <div class="col">
                            <?php
                            $this->_color_picker(
                                'aikit-chatbot-appearance-user-message-bubble-color',
                                __('User Message Bubble Color', 'aikit'),
                                'userMessageBubbleColor',
                                $chatbot_appearance_user_message_bubble_color

                            );
                            ?>
                        </div>
                        <div class="col">
                            <?php
                            $this->_color_picker(
                                'aikit-chatbot-appearance-user-message-text-color',
                                __('User Message Text Color', 'aikit'),
                                'userMessageTextColor',
                                $chatbot_appearance_user_message_text_color
                            );
                            ?>
                        </div>
                    </div>
                </div>

                <div class="col">
                    <?php
                        $this->chatbot->render(true);
                    ?>
                </div>

                <div class="row mt-3">
                    <div class="col">
                        <button class="btn btn-sm btn-primary aikit-chatbot-save-settings" type="submit"><?php echo esc_html__( 'Save Settings', 'aikit' ); ?></button>
                    </div>
                </div>

            </div>
        </form>
        <?php
    }

    public function enqueue_scripts($hook)
    {
        if ( 'aikit_page_aikit_chatbot' !== $hook ) {
            return;
        }

        $version = aikit_get_plugin_version();
        if ($version === false) {
            $version = rand( 1, 10000000 );
        }

        wp_enqueue_style( 'aikit_bootstrap_css', plugins_url( '../../css/bootstrap.min.css', __FILE__ ), array(), $version );
        wp_enqueue_style( 'aikit_bootstrap_icons_css', plugins_url( '../../css/bootstrap-icons.css', __FILE__ ), array(), $version );
        wp_enqueue_style( 'aikit_repurposer_css', plugins_url( '../../css/chatbot-settings.css', __FILE__ ), array(), $version );

        wp_enqueue_script( 'aikit_bootstrap_js', plugins_url('../../js/bootstrap.bundle.min.js', __FILE__ ), array(), $version );
        wp_enqueue_script( 'aikit_jquery_ui_js', plugins_url('../../js/jquery-ui.min.js', __FILE__ ), array('jquery'), $version );
        wp_enqueue_script( 'aikit_repurposer_js', plugins_url( '../../js/chatbot-settings.js', __FILE__ ), array( 'jquery' ), array(), $version );
    }
}
