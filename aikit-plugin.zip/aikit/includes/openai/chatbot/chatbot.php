<?php

class AIKIT_Chatbot {
    private static $instance = null;

    private $tokenizer;
    private $embeddings = null;
    private $embeddings_connector = null;

    public static function get_instance() {
        if (self::$instance == null) {
            self::$instance = new AIKIT_Chatbot();
        }

        return self::$instance;
    }

    public function __construct()
    {
        add_action( 'rest_api_init', function () {
            register_rest_route( 'aikit/chatbot/v1', '/chat', array(
                'methods' => 'POST',
                'callback' => array($this, 'handle_request'),
                'permission_callback' => function () {
                    return $this->should_show_chatbot();
                }
            ));
        });

        add_action('admin_head', array($this, 'add_inline_script'));
        add_action('wp_head', array($this, 'add_inline_script'));

        $this->tokenizer = AIKIT_Gpt3Tokenizer::getInstance();
        $this->embeddings = AIKIT_Embeddings::get_instance();
        $this->embeddings_connector = AIKIT_Embeddings_Connector::get_instance();

    }

    public function handle_request($data)
    {
        $previous_messages = json_decode($data['previous_messages'], true);
        $page_content = $data['page_content'];
        $message = $data['message'];

        $chatbot_use_embeddings = get_option('aikit_setting_chatbot_use_embeddings');
        if ($chatbot_use_embeddings == '1') {
            return $this->handle_chatbot_with_embeddings_request($message, $previous_messages);
        }

        return $this->handle_chatbot_without_embeddings_request($message, $previous_messages, $page_content);
    }

    public function handle_chatbot_with_embeddings_request($message, $previous_messages = [])
    {
        try {
            $selected_embedding_id = get_option('aikit_setting_chatbot_selected_embedding');
            $chatbot_max_tokens = intval(get_option('aikit_setting_chatbot_max_response_tokens'));
            $chatbot_context = get_option('aikit_setting_chatbot_context');
            $chatbot_model = get_option('aikit_setting_chatbot_model');

            $embedding = $this->embeddings->get_embedding_by_id($selected_embedding_id);

            if ($embedding == null) {
                return new WP_REST_Response([
                    'message' => 'Error 230: error handling request',
                ], 500);
            }

            $results = $this->embeddings_connector->query_embeddings($embedding->index_name, $message);

            if (count($results) > 0) {
                $result = $results[0];
            } else {
                $result = '';
            }

            $answer_formulating_prompt = get_option('aikit_setting_chatbot_embeddings_answer_formulation_prompt');
            $answer_formulating_prompt = str_replace('[[question]]', $message, $answer_formulating_prompt);
            $answer_formulating_prompt = str_replace('[[result]]', $result, $answer_formulating_prompt);

            $previous_messages_token_count = $this->count_tokens_in_array($previous_messages);
            $chatbot_context_token_count = $this->count_tokens_in_string($chatbot_context);
            $message_token_count = $this->count_tokens_in_string($answer_formulating_prompt);

            $model_max_tokens = aikit_get_max_tokens_for_model($chatbot_model);

            $total_token_count = $previous_messages_token_count + $chatbot_context_token_count + $message_token_count + $chatbot_max_tokens;

            if ($total_token_count > $model_max_tokens) {
                // remove words from page_content until we are under the limit
                while ($total_token_count > $model_max_tokens && !empty($page_content)) {
                    $page_content = $this->remove_last_word($page_content);
                    $page_content_token_count = $this->count_tokens_in_string($page_content);
                    $total_token_count = $previous_messages_token_count + $chatbot_context_token_count + $message_token_count + $chatbot_max_tokens;
                }

                if ($total_token_count > $model_max_tokens) {
                    // remove words from chatbot_context until we are under the limit
                    while ($total_token_count > $model_max_tokens && !empty($chatbot_context)) {
                        $chatbot_context = $this->remove_last_word($chatbot_context);
                        $chatbot_context_token_count = $this->count_tokens_in_string($chatbot_context);
                        $total_token_count = $previous_messages_token_count + $chatbot_context_token_count + $message_token_count + $chatbot_max_tokens;
                    }
                }
            }

            $result_message = aikit_openai_chat_generation_request(
                $answer_formulating_prompt,
                $chatbot_max_tokens,
                $chatbot_context,
                $previous_messages,
            );

            return new WP_REST_Response([
                'message' => $result_message,
            ], 200);

        } catch (Throwable $e) {
            $is_admin = current_user_can('manage_options');
            $message = $is_admin ? $e->getMessage() : 'An error occurred while generating the response.';
            return new WP_REST_Response([
                'message' => $message,
                'show_in_alert' => $is_admin,
                'trace' => $e->getTraceAsString(),
                'chat_error' => __('Error 190: An error occurred while generating the response, please try again later.', 'aikit'),
            ], 500);
        }
    }

    public function handle_chatbot_without_embeddings_request($message, $previous_messages = [], $page_content = '')
    {
        $chatbot_model = get_option('aikit_setting_chatbot_model');
        $chatbot_context = get_option('aikit_setting_chatbot_context');
        $chatbot_is_page_content_aware = boolval(get_option('aikit_setting_chatbot_is_page_content_aware'));
        $chatbot_max_tokens = intval(get_option('aikit_setting_chatbot_max_response_tokens'));

        $previous_messages_token_count = $this->count_tokens_in_array($previous_messages);
        $chatbot_context_token_count = $this->count_tokens_in_string($chatbot_context);
        $page_content_token_count = $this->count_tokens_in_string($page_content);
        $message_token_count = $this->count_tokens_in_string($message);

        $model_max_tokens = aikit_get_max_tokens_for_model($chatbot_model);

        $total_token_count = $previous_messages_token_count + $chatbot_context_token_count + $page_content_token_count + $message_token_count + $chatbot_max_tokens;

        if ($total_token_count > $model_max_tokens) {
            // remove messages from previous_messages until we are under the limit
            while ($total_token_count > $model_max_tokens && !empty($previous_messages)) {
                array_shift($previous_messages);
                $previous_messages_token_count = $this->count_tokens_in_array($previous_messages);
                $total_token_count = $previous_messages_token_count + $chatbot_context_token_count + $page_content_token_count + $message_token_count + $chatbot_max_tokens;
            }

            if ($total_token_count > $model_max_tokens) {
                // remove words from page_content until we are under the limit
                while ($total_token_count > $model_max_tokens && !empty($page_content)) {
                    $page_content = $this->remove_last_word($page_content);
                    $page_content_token_count = $this->count_tokens_in_string($page_content);
                    $total_token_count = $previous_messages_token_count + $chatbot_context_token_count + $page_content_token_count + $message_token_count + $chatbot_max_tokens;
                }
            }

            if ($total_token_count > $model_max_tokens) {
                // remove words from chatbot_context until we are under the limit
                while ($total_token_count > $model_max_tokens && !empty($chatbot_context)) {
                    $chatbot_context = $this->remove_last_word($chatbot_context);
                    $chatbot_context_token_count = $this->count_tokens_in_string($chatbot_context);
                    $total_token_count = $previous_messages_token_count + $chatbot_context_token_count + $page_content_token_count + $message_token_count + $chatbot_max_tokens;
                }
            }
        }

        if ($chatbot_is_page_content_aware && (!empty($page_content) || !empty($chatbot_context))) {
            $chatbot_context = $chatbot_context . "\nExtra context to use for your answers:\n" . $page_content;
        }

        try {
            $result_message = aikit_openai_chat_generation_request(
                $message,
                $chatbot_max_tokens,
                $chatbot_context,
                $previous_messages,
            );
        } catch (Throwable $e) {
            $is_admin = current_user_can('manage_options');
            $message = $is_admin ? $e->getMessage() : 'An error occurred while generating the response.';
            return new WP_REST_Response([
                'message' => $message,
                'show_in_alert' => $is_admin,
                'chat_error' => __('Error 200: An error occurred while generating the response, please try again.', 'aikit'),
            ], 500);
        }

        return new WP_REST_Response([
            'message' => $result_message,
        ], 200);
    }

    private function remove_last_word($str)
    {
        $str = trim($str);
        $words = explode(' ', $str);

        if (count($words) <= 1) {
            return '';
        }

        array_pop($words);
        return implode(' ', $words);
    }

    private function count_tokens_in_string($str)
    {
        return $this->tokenizer->count($str);
    }

    private function count_tokens_in_array($arr) {
        $count = 0;

        foreach ($arr as $item) {
            $count += $this->count_tokens_in_string($item['message'] ?? '');
        }

        return $count;
    }

    public function add_inline_script()
    {
        $nonce = wp_create_nonce('wp_rest');
        $vars = array(
            'nonce'  =>  $nonce,
            'siteUrl' => get_site_url(),
            'pageContent' => $this->get_current_page_content(),
            'mainColor' => get_option('aikit_setting_chatbot_appearance_main_color'),
            'aiMessageBubbleColor' => get_option('aikit_setting_chatbot_appearance_ai_message_bubble_color'),
            'aiMessageTextColor' => get_option('aikit_setting_chatbot_appearance_ai_message_text_color'),
            'userMessageBubbleColor' => get_option('aikit_setting_chatbot_appearance_user_message_bubble_color'),
            'userMessageTextColor' => get_option('aikit_setting_chatbot_appearance_user_message_text_color'),
            'titleColor' => get_option('aikit_setting_chatbot_appearance_title_color'),
            'width' => get_option('aikit_setting_chatbot_appearance_width'),
            'title' => get_option('aikit_setting_chatbot_appearance_title'),
            'startMessage' => get_option('aikit_setting_chatbot_appearance_start_message'),
        );

        wp_add_inline_script( 'aikit-chatbot', 'var aikitChatbot =' . json_encode($vars) );

        wp_enqueue_script( 'aikit-chatbot');
    }

    private function get_current_page_content()
    {
        if (!get_option('aikit_setting_chatbot_is_page_content_aware')) {
            return '';
        }

        if (is_admin()) {
            return '';
        }

        $page_id = get_the_ID();
        $content = get_post_field('post_content', $page_id);

        // strip shortcodes
        $content = strip_shortcodes($content);

        // strip tags
        return strip_tags($content);
    }

    public function init()
    {
        $show_on = get_option('aikit_setting_chatbot_show_on');

        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

        if ($show_on == 'all') {
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        } else if ($show_on == 'frontend') {
            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        } else if ($show_on == 'admin') {
            add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        }

        // if current page is aikit_chatbot, return
        if ($this->is_chatbot_settings_page()) {
            return;
        }

        if ($show_on == 'all') {
            add_action( 'admin_footer', array( $this, 'render' ) );
            add_action( 'wp_footer', array( $this, 'render' ) );
        } else if ($show_on == 'frontend') {
            add_action( 'wp_footer', array( $this, 'render' ) );
        } else if ($show_on == 'admin') {
            add_action( 'admin_footer', array( $this, 'render' ) );
        }
    }

    private function is_chatbot_settings_page()
    {
        return isset($_GET['page']) && $_GET['page'] == 'aikit_chatbot';
    }

    private function should_show_chatbot($live_preview = false)
    {
        if ($live_preview) {
            return true;
        }

        if (!get_option('aikit_setting_chatbot_enabled')) {
            return false;
        }

        $should_show_for_roles = get_option('aikit_setting_chatbot_show_only_for_roles');

        if ($should_show_for_roles != 'all') {
            $current_user_roles = wp_get_current_user()->roles;
            $should_show = false;
            foreach ($current_user_roles as $role) {
                if ($role == $should_show_for_roles) {
                    $should_show = true;
                    break;
                }
            }

            if (!$should_show) {
                return false;
            }
        }

        return true;
    }

    public function render($live_preview = false)
    {
        if (!$this->should_show_chatbot($live_preview)) {
            return;
        }

        $chatbot_appearance_title = get_option('aikit_setting_chatbot_appearance_title');
        $chatbot_appearance_start_message = get_option('aikit_setting_chatbot_appearance_start_message');

        $default_view = get_option('aikit_setting_chatbot_default_view');
        $collapsed_class = $default_view == 'collapsed' && !$this->is_chatbot_settings_page() ? 'aikit-chatbot-collapsed' : '';

        $input_placeholder = get_option('aikit_setting_chatbot_appearance_input_placeholder');

        ?>
            <div class="aikit-chatbot <?php echo esc_attr($collapsed_class); ?>">
                <div class="aikit-chatbot-chat-space">
                    <div class="aikit-chatbot-header">
                        <h2><?php echo esc_html($chatbot_appearance_title); ?></h2>
                        <a class="aikit-chatbot-close"><i class="bi bi-chevron-double-down"></i></a>
                    </div>
                    <div class="aikit-chatbot-messages">
                        <span class="aikit-chat-bubble"><?php echo esc_html($chatbot_appearance_start_message); ?></span>
                        <?php if ($live_preview) {?>
                            <span class="aikit-chat-bubble reply">Can you please help me with...</span>
                            <span class="aikit-chat-bubble-loading-container">
                                <span class="aikit-chat-bubble aikit-chat-bubble-loading">
                                    <span class="aikit-typing">
                                        <span class="aikit-dot"></span>
                                        <span class="aikit-dot"></span>
                                        <span class="aikit-dot"></span>
                                    </span>
                                </span>
                            </span>
                        <?php } ?>

                    </div>
                </div>
                <div class="aikit-chatbot-footer">
                    <textarea class="aikit-chatbot-message" placeholder="<?php echo esc_html($input_placeholder) ?>" ></textarea>
                    <div class="aikit-chatbot-send-container">
                        <div class="aikit-chatbot-send-wrapper">
                            <button class="aikit-chatbot-send"><i class="bi bi-send-fill"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        <?php
    }

    public function enqueue_scripts($hook)
    {
        $version = aikit_get_plugin_version();
        if ($version === false) {
            $version = rand( 1, 10000000 );
        }

        wp_enqueue_style( 'aikit_bootstrap_icons_css', plugins_url( '../../css/bootstrap-icons.css', __FILE__ ), array(), $version );

        wp_enqueue_style('aikit-chatbot', plugins_url('../../css/chatbot.css', __FILE__));
        wp_enqueue_script('aikit-chatbot', plugins_url('../../js/chatbot.js', __FILE__), array('jquery'), $version, true);
    }
}