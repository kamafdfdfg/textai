<?php

use AIKit\Dependencies\Qdrant\Http\GuzzleClient;
use AIKit\Dependencies\Qdrant\Models\Request\CreateCollection;
use AIKit\Dependencies\Qdrant\Models\Request\SearchRequest;
use AIKit\Dependencies\Qdrant\Models\Request\VectorParams;
use AIKit\Dependencies\Qdrant\Config;
use AIKit\Dependencies\Qdrant\Models\VectorStruct;
use AIKit\Dependencies\Qdrant\Qdrant;
use AIKit\Dependencies\Qdrant\Models\PointStruct;
use \AIKit\Dependencies\Qdrant\Models\PointsStruct;
use \AIKit\Dependencies\GuzzleHttp\Client;

class AIKIT_Embeddings_Connector {

    const QDRANT_VECTOR_NAME = 'chatbot';

    // singleton
    private static $instance = null;

    private $tokenizer;

    private function __construct() {
        $this->tokenizer = new AIKIT_Gpt3Tokenizer(new AIKIT_Gpt3TokenizerConfig());
    }

    public static function get_instance() {
        if (self::$instance == null) {
            self::$instance = new AIKIT_Embeddings_Connector();
        }
        return self::$instance;
    }

    public function create_embeddings($index_name, $data_records)
    {
        var_dump($index_name);
        $this->create_collection($index_name);
        $client = $this->get_qdrant_client();

        $points = new PointsStruct();

        $strings = array();
        foreach ($data_records as $data_record) {
            $split_strings = $this->adjust_string_to_max_token_count($data_record);
            $strings = array_merge($strings, $split_strings);
        }

        foreach ($strings as $string) {
            $vector_data = $this->build_embeddings_vector($string);

            $vector = new VectorStruct($vector_data, self::QDRANT_VECTOR_NAME);
            $id = $this->hash_string($string);

            $point = new PointStruct($id, $vector,
                [
                    'data' => $string
                ]);

            $points->addPoint($point);
        }

        if (count($points->getPoints()) == 0) {
            return;
        }

        $response = $client->collections($index_name)->points()->upsert(
            $points,
            [
                'wait' => 'true'
            ]
        );

        if (!$this->is_qdrant_response_success($response)) {
            throw new Exception('Qdrant error - could not create embeddings. Error details: ' . json_encode($response->__toArray()));
        }
    }

    public function delete_collection($collection_name)
    {
        $client = $this->get_qdrant_client();
        $client->collections($collection_name)->delete();

    }

    private function hash_string($string, $digits = 10) {
        $m = pow(10, $digits + 1) - 1;
        $phi = pow(10, $digits) / 2 - 1;
        $n = 0;
        for ($i = 0; $i < strlen($string); $i++) {
            $n = ($n + $phi * ord($string[$i])) % $m;
        }

        return intval($n);
    }

    private function create_collection($collection_name)
    {
        $client = $this->get_qdrant_client();

        $createCollection = new CreateCollection();
        $createCollection->addVector(new VectorParams(1536, VectorParams::DISTANCE_COSINE), self::QDRANT_VECTOR_NAME);
        $collectionsResponse = $client->collections($collection_name)->list();

        // if collection already exists, return
        if ($collectionsResponse->offsetExists('result')) {
            $result = $collectionsResponse->offsetGet('result');
            $collections = $result['collections'] ?? array();

            foreach ($collections as $collection) {
                if ($collection['name'] == $collection_name) {
                    return;
                }
            }
        }

        $response = $client->collections($collection_name)->create($createCollection);

        if (!$this->is_qdrant_response_success($response)) {
            throw new Exception('Qdrant error - could not create collection. Error details: ' . json_encode($response->__toArray()));
        }
    }

    private function get_qdrant_client()
    {
        $config = new Config(get_option('aikit_setting_qdrant_host'));
        $api_key = get_option('aikit_setting_qdrant_api_key');

        if (!empty($api_key)) {
            $config->setApiKey($api_key);
        }

        return new Qdrant(new GuzzleClient($config));
    }

    public function query_embeddings($index_name, $query, $num_results = 1)
    {
        $client = $this->get_qdrant_client();

        $vector_data = $this->build_embeddings_vector($query);
        $vector = new VectorStruct($vector_data, self::QDRANT_VECTOR_NAME);

        $search_request = new SearchRequest($vector);
        $search_request->setLimit($num_results);
        $search_request->setWithPayload(true);
        $search_request->setScoreThreshold(0.7);

        $response = $client->collections($index_name)->points()->search(
            $search_request
        );

        $results = $response->offsetGet('result');

        $results_to_return = array();
        foreach ($results as $result) {
            $results_to_return[] = $result['payload']['data'];
        }


        return $results_to_return;
    }

    private function build_embeddings_vector($string)
    {
        $client = new Client();
        try {
            $imageResponse = $client->request( 'POST', 'https://api.openai.com/v1/embeddings', [
                'body'    => json_encode( [
                    'model'  => AIKIT_Embeddings::OPENAI_EMBEDDINGS_MODEL_NAME,
                    'input'  => $string,
                ] ),
                'headers' => [
                    'Authorization' => 'Bearer ' . get_option( 'aikit_setting_openai_key' ),
                    'Content-Type'  => 'application/json',
                ],
            ] );

        } catch (\AIKit\Dependencies\GuzzleHttp\Exception\ClientException $e) {
            return new WP_Error( 'openai_error', json_encode([
                'message' => 'error while calling openai embeddings',
                'responseBody' => $e->getResponse()->getBody()->getContents(),
            ]), array( 'status' => 500 ) );
        } catch (\AIKit\Dependencies\GuzzleHttp\Exception\GuzzleException $e) {
            return new WP_Error( 'openai_error', json_encode([
                'message' => 'error while calling openai embeddings',
                'responseBody' => $e->getMessage(),
            ]), array( 'status' => 500 ) );
        }

        $body = $imageResponse->getBody();
        $json = json_decode($body, true);
        $data = $json['data'] ?? [];

        if (empty($data)) {
            throw new Exception('OpenAI error - could not get data. Error details: ' . json_encode($json));
        }

        $data = $data[0] ?? [];

        $embedding = $data['embedding'] ?? [];

        if (empty($embedding)) {
            throw new Exception('OpenAI error - could not get embeddings. Error details: ' . json_encode($json));
        }

        return $embedding;
    }

    private function adjust_string_to_max_token_count($string, $max_token_count = 2000)
    {
        $token_count = $this->tokenizer->count($string);

        if ($token_count <= $max_token_count) {
            return [$string];
        }

        $pieces_count = ceil($token_count / $max_token_count) + 1;
        $pieces = array();

        $string_parts = preg_split('/\s+/u', $string);
        $string_parts_count = count($string_parts);

        for ($i = 0; $i < $pieces_count; $i++) {
            $start_index = floor($i * $string_parts_count / $pieces_count);
            $end_index = floor(($i + 1) * $string_parts_count / $pieces_count);
            $pieces[] = implode(' ', array_slice($string_parts, $start_index, $end_index - $start_index));
        }

        return $pieces;
    }

    private function is_qdrant_response_success ($response) {
        if ($response->offsetExists('result')) {
            $result = $response->offsetGet('result');

            return $result['status'] == 'completed' || $result === true;
        }

        return false;
    }

}